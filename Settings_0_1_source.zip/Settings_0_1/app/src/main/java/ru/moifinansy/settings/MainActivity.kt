package ru.moifinansy.settings

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateFormat
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import java.util.Date

class MainActivity : Activity() {
    private lateinit var eventsBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 24)
            setBackgroundColor(0xFFF4F6F7.toInt())
        }

        page.addView(TextView(this).apply {
            text = "Настройки 0.1"
            textSize = 26f
            setTextColor(0xFF172126.toInt())
        })
        page.addView(TextView(this).apply {
            text = "Тест перехвата уведомлений Яндекс Пэй"
            textSize = 15f
            setTextColor(0xFF58666D.toInt())
            setPadding(0, 8, 0, 20)
        })

        page.addView(Button(this).apply {
            text = "1. Разрешить доступ к уведомлениям"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })
        page.addView(Button(this).apply {
            text = "2. Обновить список"
            setOnClickListener { renderEvents() }
        })
        page.addView(Button(this).apply {
            text = "Очистить историю"
            setOnClickListener {
                getSharedPreferences(NotificationCaptureService.PREFS, MODE_PRIVATE)
                    .edit().remove(NotificationCaptureService.KEY_EVENTS).apply()
                renderEvents()
            }
        })

        page.addView(TextView(this).apply {
            text = "Найденные уведомления"
            textSize = 19f
            setTextColor(0xFF172126.toInt())
            setPadding(0, 22, 0, 10)
        })

        val scroll = ScrollView(this)
        eventsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(eventsBox)
        page.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(page)
        renderEvents()
    }

    override fun onResume() {
        super.onResume()
        if (::eventsBox.isInitialized) renderEvents()
    }

    private fun renderEvents() {
        eventsBox.removeAllViews()
        val raw = getSharedPreferences(NotificationCaptureService.PREFS, MODE_PRIVATE)
            .getString(NotificationCaptureService.KEY_EVENTS, "[]")
        val events = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }

        if (events.length() == 0) {
            eventsBox.addView(TextView(this).apply {
                text = "Пока уведомлений нет. Разреши доступ, затем сделай тестовый перевод и нажми «Обновить список»."
                textSize = 15f
                setTextColor(0xFF58666D.toInt())
                setPadding(0, 8, 0, 8)
            })
            return
        }

        for (i in 0 until events.length()) {
            val item = events.getJSONObject(i)
            val time = DateFormat.getMediumDateFormat(this).format(Date(item.optLong("time"))) +
                " " + DateFormat.getTimeFormat(this).format(Date(item.optLong("time")))
            val card = TextView(this).apply {
                text = "${item.optString("app")}\n${item.optString("title")}\n${item.optString("text")}\n$time"
                textSize = 15f
                setTextColor(0xFF172126.toInt())
                setPadding(20, 18, 20, 18)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 0, 0, 12)
            eventsBox.addView(card, params)
        }
    }
}
