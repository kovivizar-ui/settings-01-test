package ru.moifinansy.settings

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class NotificationCaptureService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val appName = try {
            val app = packageManager.getApplicationInfo(sbn.packageName, 0)
            packageManager.getApplicationLabel(app).toString()
        } catch (_: Exception) {
            sbn.packageName
        }

        // MVP: записываем только уведомления приложений, название которых похоже на Яндекс Пэй.
        val normalized = appName.lowercase()
        if (!normalized.contains("яндекс") && !normalized.contains("yandex") &&
            !normalized.contains("pay")) return

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString(KEY_EVENTS, "[]")) } catch (_: Exception) { JSONArray() }
        val item = JSONObject().apply {
            put("app", appName)
            put("package", sbn.packageName)
            put("title", title)
            put("text", text)
            put("time", sbn.postTime)
        }
        val updated = JSONArray()
        updated.put(item)
        for (i in 0 until minOf(old.length(), 49)) updated.put(old.getJSONObject(i))
        prefs.edit().putString(KEY_EVENTS, updated.toString()).apply()
    }

    companion object {
        const val PREFS = "notification_capture"
        const val KEY_EVENTS = "events"
    }
}
